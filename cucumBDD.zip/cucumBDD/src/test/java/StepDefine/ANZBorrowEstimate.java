package StepDefine;



import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

/*
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
*/
//import java.util.List;

//import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

//import Utilities.commonutils;
//import io.cucumber.java.Before;
//import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ANZBorrowEstimate {
	
	WebDriver driver;
	String Dri_Loc;
	String ANZ_URL;


	@Given("user entering url")
	public void user_entering() {
	    // Write code here that turns the phrase above into concrete actions
		
		FileReader reader=null;
		try {
			reader=new FileReader("config.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
				Properties properties=new Properties();
				try {
					properties.load(reader);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
				
				Dri_Loc=properties.getProperty("DriverLocation");
				ANZ_URL=properties.getProperty("Appurl");
				//brow_ser=properties.getProperty("chrome");
				
		
		System.setProperty("webdriver.chrome.driver", Dri_Loc);
		driver = new ChromeDriver();
		driver.get(ANZ_URL);
		driver.manage().window().maximize();
	}
	
	@When("User on How much could i Borrow page")
	public void user_on_How_much_could_i_Borrow_page() {
	    // Write code here that turns the phrase above into concrete actions
		String Title= driver.getTitle();
		if(Title.contains("borrowing")==true)
			System.out.println("User on Borrowing Estimate page");
		else
			System.out.println("User not landed on Borrowing Estimate page");
	}
	@When("User select your details Application Type {string}")
	public void user_select_your_details_application_type(String AppType) {
	    // Write code here that turns the phrase above into concrete actions
				
		//List<List<String>> User=dataTable.asLists(String.class);
		//String AppType = User.get(1).get(0);
		
		if (AppType.equals("Single"))
		
		driver.findElement(By.id("application_type_single")).click();
		else		
		driver.findElement(By.id("application_type_joint")).click(); 
			
	}

	@When("User select your details Number of Dependents {int}")
	public void user_select_your_details_number_of_dependents(int Dep) {
	    // Write code here that turns the phrase above into concrete actions
		WebElement Dropdown=driver.findElement(By.xpath("//*[@id=\"main-container\"]/div[1]/div/div/div[2]/div/div/div/div/div[1]/div/div[2]/div/div[1]/div/div[2]/div/select"));
		Select select=new Select(Dropdown);
		select.selectByIndex(Dep);
	}
	@When("User select your details Property you would like to buy {string}")
	public void user_select_your_details_property_you_would_like_to_buy(String PropertyType) {
	    // Write code here that turns the phrase above into concrete actions
		//List<List<String>> User=dataTable.asLists(String.class);
		//String PropertyType = User.get(1).get(0);
		if(PropertyType.contains("Home"))
		driver.findElement(By.id("borrow_type_home")).click();
	}
	@When("User select your earnings income {double}")
	public void user_select_your_earnings_income(Double Your_income)  {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//label[contains(text(),'Your income')]/following::div[1]/child::input")).sendKeys(Your_income.toString());
	}
	@When("User select your earnings Other income {double}")
	public void user_select_your_earnings_other_income(Double other_income) {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//label[text()='Your other income']/following::div[1]/child::input")).sendKeys(other_income.toString());
	}
	
	@When("User select your earnings income2 {double}")
	public void user_select_your_earnings_income2(Double Your_income2)  {
	    // Write code here that turns the phrase above into concrete actions
		WebElement jointincome=driver.findElement(By.xpath("//label[@id='q2q3']/following-sibling::div[1]/child::input[1]"));
		if(jointincome.isDisplayed())
			jointincome.sendKeys(Your_income2.toString());
	}
	@When("User select your earnings Other income2 {double}")
	public void user_select_your_earnings_other_income2(Double other_income2) {
	    // Write code here that turns the phrase above into concrete actions
		WebElement jointotherincome=driver.findElement(By.xpath("//label[@id='q2q4']/following-sibling::div[1]/child::input[1]"));
		if(jointotherincome.isDisplayed())
			jointotherincome.sendKeys(other_income2.toString());
	}
	
	
	@When("User select your Expenses Living Expenses {int}")
	public void user_select_your_expenses_living_expenses(Integer expenses) {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("expenses")).sendKeys(expenses.toString());
	}
	@When("User select your Expenses Current Home Repayment {int}")
	public void user_select_your_expenses_current_home_repayment(Integer homeloans)  {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("homeloans")).sendKeys(homeloans.toString());
	}
	@When("User select your Expenses Other Loan Repayments {int}")
	public void user_select_your_expenses_other_loan_repayments(Integer otherloans) {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("otherloans")).sendKeys(otherloans.toString());
	}
	@When("User select your Expenses Other commitments {int}")
	public void user_select_your_expenses_other_commitments(Integer other_commit) {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//label[@id='q3q4']/following::div[1]/child::input")).sendKeys(other_commit.toString());
	}
	@When("User select your Expenses total credit card limits {double}")
	public void user_select_your_expenses_total_credit_card_limits(Double CC_limit) {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("credit")).sendKeys(CC_limit.toString());
	}
	
	@When("User select Work out how much I could borrow button")
	public void user_select_work_out_how_much_i_could_borrow_button() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("btnBorrowCalculater")).click();
		//Thread.sleep(2000);
		WebElement Fieldvalueamount=driver.findElement(By.id("borrowResultTextAmount"));
		String Field_value= Fieldvalueamount.getText();
		while( !Fieldvalueamount.getText().equals(Field_value))
		{
			Field_value= Fieldvalueamount.getText();
		}
		//driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
	
	@Then("User see the Borrowing Estimate")
	public void user_see_the_borrowing_estimate() {
	    // Write code here that turns the phrase above into concrete actions
		WebElement EstimateAmount=driver.findElement(By.id("borrowResultTextAmount"));
		WebElement ErrorText=driver.findElement(By.className("borrow__error__text"));
		if(EstimateAmount.isDisplayed()) {
			System.out.println(EstimateAmount.getText());
			driver.close();
		}
		else if (ErrorText.isDisplayed()) {
			System.out.println(ErrorText.getText());
			driver.close();
		}
			

	}
	
	@When("User click on startover button")
	public void user_click_on_startover_button() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.className("start-over")).click();
	}
	@Then("User should see the Details cleared estimate form")
	public void user_should_see_the_details_cleared_estimate_form() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("form cleared");
		Boolean Startovericon=driver.findElement(By.className("start-over")).isDisplayed();
		Boolean Borrowcalculatorbtn=driver.findElement(By.id("btnBorrowCalculater")).isDisplayed();
		if(Startovericon.equals(false)&&Borrowcalculatorbtn.equals(true))
			System.out.println("form successfully cleared");
			
/*		String Defaultincome=driver.findElement(By.xpath("//label[contains(text(),'Your income')]/following::div[1]/child::input")).getAttribute("value");
		System.out.println(Defaultincome);
		String Defaultotherincome=driver.findElement(By.xpath("//label[text()='Your other income']/following::div[1]/child::input")).getAttribute("value");
		System.out.println(Defaultotherincome);
		String Defaultlivingexpense=driver.findElement(By.id("expenses")).getAttribute("value");
		System.out.println(Defaultlivingexpense);
		String Defaultcurrentloanrepay=driver.findElement(By.id("homeloans")).getAttribute("value");
		System.out.println(Defaultcurrentloanrepay);
		String Defaultotherloanrepay=driver.findElement(By.id("otherloans")).getAttribute("value");
		System.out.println(Defaultotherloanrepay);
		String Defaultothercommits=driver.findElement(By.xpath("//label[@id='q3q4']/following::div[1]/child::input")).getText();
		System.out.println(Defaultothercommits);
		String Defaultcredits=driver.findElement(By.id("credit")).getText();
		System.out.println(Defaultcredits);
		if(Defaultincome.equals("0")&&Defaultotherincome.equals("0")&&Defaultlivingexpense.equals("0")&&Defaultcurrentloanrepay.equals("0")&&Defaultotherloanrepay.equals("0")&&Defaultothercommits.equals("0")&&Defaultcredits.equals("0"))
		{
			System.out.println("All the fields are defaulted to zero, form cleared");
		}
		else
		{
			System.out.println("Form not cleared");
		}
		*/
		driver.close();
		
	
	}


}
